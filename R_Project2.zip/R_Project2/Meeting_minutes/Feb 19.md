Agenda

- Confirm how to proceed with paired-end sequences in Qiime 
- Rediscuss all the aims 
- Reframe the research question 

Meeting Minutes 

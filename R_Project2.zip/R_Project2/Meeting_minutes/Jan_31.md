## MICB475: Data Science Research in Microbiology
Team 2 - QingRu Kong, Pranjali Singh, Ran Tao, Tina Wang, Zurui Zhu

Jan 31st, 2025 

### Meeting Minutes 

Future meeting action items:
- Make agenda before the meeting (before Thursday night) and post on github
- Add Evelyn and Hans to our Github
- For every meeting, there should be a note taker and a leader

Project 2 action items
- Send a list of papers (with potential research questions) to Evelyn before Monday, Feb. 3rd
- Need to decide a research question before next meeting, Feb. 7th

Notes taken by: Ran Tao

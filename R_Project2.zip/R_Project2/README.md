# MICB 475: Data Science Reserach in Microbiology
### QingRu Kong, Pranjali Singh, Ran Tao, Keheng Wang, Zurui Zhu
